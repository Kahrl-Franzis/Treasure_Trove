package com.asis.service;

public interface CustomerService {

}
