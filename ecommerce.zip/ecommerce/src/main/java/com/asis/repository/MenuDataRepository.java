package com.asis.repository;

import com.asis.entity.MenuData;
import org.springframework.data.repository.CrudRepository;

public interface MenuDataRepository extends CrudRepository<MenuData,Integer> {
}
