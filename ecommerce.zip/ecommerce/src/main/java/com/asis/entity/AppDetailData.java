package com.asis.entity;

public class AppDetailData {
}
