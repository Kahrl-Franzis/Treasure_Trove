package com.asis.model;

public class Category {
    int id;
    String name;
    String description;
}
