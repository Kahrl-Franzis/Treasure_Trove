package com.asis.model;

import java.util.List;

public class Order {
    int id;
    String customerId;
    List<OrderItem> items;
}
