// src/app/product-order/product-order.component.ts

import { Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router'; // <-- ADD RouterModule
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http'; 

// FIX: Corrected paths using two levels up (../../) to reach the 'service' and 'model' folders
import { CartService } from '../service/cart.service'; 
import { OrderService } from '../service/order.service'; 
import { OrderPostModel, OrderModel } from '../model/order.model'; 


@Component({
  selector: 'app-product-order',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './product-order.component.html',
  styleUrls: ['./product-order.component.css']
})
export class ProductOrderComponent implements OnInit {
  // CRITICAL: Hardcode Pirate ID 1, as we don't have login/authentication set up
  pirateId: number = 1; 
  orderPayload!: OrderPostModel;
  orderStatusMessage: string = '';
  isProcessing: boolean = false;

  constructor(
    private cartService: CartService,
    private orderService: OrderService,
    private router: Router
  ) { }

  ngOnInit(): void {
    // Prepare the order data for display before final submission
    this.orderPayload = this.cartService.prepareOrderPayload(this.pirateId);
    
    // Redirect if cart is empty
    if (!this.orderPayload.orderItems || this.orderPayload.orderItems.length === 0) {
      this.router.navigate(['/chest']); 
    }
  }

  confirmAndSetSail(): void {
    this.isProcessing = true;
    this.orderStatusMessage = 'Sending manifest... Setting sail...';

    this.orderService.placeOrder(this.orderPayload).subscribe({
      next: (response: OrderModel) => { 
        this.orderStatusMessage = `Loot Secured! Order ID ${response.id}. Your shipment is setting sail! 🚢`;
        this.cartService.clearCart(); // Clear the client-side cart state
        this.isProcessing = false;
      },
      error: (err: HttpErrorResponse) => { 
        this.isProcessing = false;
        // Access err.error to get the message from your Spring backend
        this.orderStatusMessage = `ERROR! Treasure lost! ${err.error.message || err.message || 'Check backend logs for details.'}`; 
        console.error('Order Submission Failed:', err);
      }
    });
  }
}