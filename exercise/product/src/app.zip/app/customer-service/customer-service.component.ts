// src/app/customer-service/customer-service.component.ts

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common'; 
import { FormsModule } from '@angular/forms';     // CRITICAL FIX 1: For [(ngModel)]
import { RouterModule } from '@angular/router';
import { Pirate } from '../model/pirate'; 
import { CustomerService } from '../service/customer.service';

@Component({
  selector: 'app-customer-service',
  standalone: true,
  // CRITICAL FIX 2: Add FormsModule and CommonModule to imports
  imports: [CommonModule, FormsModule, RouterModule], 
  templateUrl: './customer-service.component.html',
  styleUrls: ['./customer-service.component.css'],
})
export class CustomerServiceComponent implements OnInit {
    // CRITICAL: The component logic that was failing compilation
    isLoginView: boolean = true; 
    loginForm = { username: '', password: '' };
    registerForm: Pirate = { 
        id: 0,
        username: '', 
        email: '', 
        passwordHash: '', 
        defaultShippingAddress: '' 
    };
    message: string = '';

    constructor(private customerService: CustomerService) {}

    ngOnInit(): void {}

    handleRegister(): void {
        this.message = 'Attempting to join the crew...';
        // Logic to call customerService.registerPirate() goes here
        this.message = 'Placeholder: Registration Successful';
    }

    handleLogin(): void {
        this.message = 'Placeholder: Login Successful';
    }

    toggleView(): void {
        this.isLoginView = !this.isLoginView;
        this.message = '';
    }
}