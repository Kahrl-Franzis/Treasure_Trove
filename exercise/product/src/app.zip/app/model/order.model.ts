// src/app/model/order.model.ts

// The structure used inside the orderItems array
export interface OrderItemModel {
  product: { id: number }; // Only need the product ID
  quantity: number;
}

// The complete payload sent to the /api/orders endpoint
export interface OrderPostModel {
  pirate: { id: number }; // The customer's ID (must be sent)
  totalAmount: number;
  status: string;
  orderItems: OrderItemModel[];
}

// The structure expected back from the server response
export interface OrderModel {
    id: number;
    // Add other fields you expect to get back
}