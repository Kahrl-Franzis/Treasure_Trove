// src/app/product-category/product-category.component.ts

import { Component, OnInit } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common'; 
import { RouterModule } from '@angular/router';
// ... other imports ...

@Component({
  // ... selector and template setup ...
  standalone: true,
  // FIX: Ensure CommonModule and DecimalPipe are present
  imports: [CommonModule, DecimalPipe, RouterModule], 
  // ... rest of the component
})
export class ProductCategoryComponent implements OnInit {
    public products: any[] = []; // Keep this definition
    // CRITICAL FIX: Add the missing 'errorMessage' property
    public errorMessage: string = ''; 

    // ... constructor ...

    ngOnInit(): void {
        // ... fetching logic ...
        this.productService.getData().subscribe({
          next: (data) => {
            this.products = data;
          },
          error: (err) => {
            // This is where 'errorMessage' is used
            this.errorMessage = 'Failed to load treasures. Check backend connection.';
          }
        });
    }
    // ... stashInChest method ...
}