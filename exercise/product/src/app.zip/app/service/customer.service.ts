// src/app/service/customer.service.ts

import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Observable } from 'rxjs';
import { Pirate } from '../model/Pirate'; // Must match the component import

@Component({
  selector: 'app-customer-service',
  standalone: true,
  // CRITICAL FIX: Add FormsModule and CommonModule to imports
  imports: [CommonModule, FormsModule, RouterModule], 
  templateUrl: './customer-service.component.html',
  styleUrls: ['./customer-service.component.css'],
})

export class CustomerService {
  private apiUrl = 'http://localhost:8080/api/pirates'; // Base endpoint for Pirate CRUD

  constructor(private http: HttpClient) { }
  
  /**
   * CRITICAL FIX: Implement the registerPirate method the component is looking for.
   * (Backend: POST to /api/pirates)
   */
  registerPirate(pirate: Pirate): Observable<Pirate> {
    // Note: The backend uses the POST method for creating new resources.
    return this.http.post<Pirate>(this.apiUrl, pirate);
  }

  // Optional: Add find method for the component (needed for Login/GET operations)
  findPirateById(id: number): Observable<Pirate> {
    return this.http.get<Pirate>(`${this.apiUrl}/${id}`);
  }
}